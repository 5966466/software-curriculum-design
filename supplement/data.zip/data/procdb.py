import glob
import os

#pics = glob.iglob('test/[0-9]/*.jpg')
def update(path):
    path_f = os.path.join(path, 'test_list.txt')
    f = open(path_f, 'w')
    pics = glob.iglob(os.path.join(path, 'test', '[0-9]', '*.jpg'))
    for p in pics:
        label = os.path.basename(p).split('_')[0]
        path = os.path.join(os.getcwd(), p) + ';'
        in_line = path+label+'\n'
        print(in_line.strip())
        f.write(in_line)


"""
pictures = glob.glob('data/train/*.png') # read all pictures
labels = ['airplane', 'automobile', 'bird', 'cat', 'deer', \
        'dog', 'frog', 'horse', 'ship', 'truck']

train_dict = {} # name of the picture
with open('data/trainlabels.txt', 'r') as f: # close automatically
    for line in f.readlines():
        name = line.strip().split(',')
        train_dict.update({name[0]: [labels.index(name[1])]})

f = open('train_list.txt', 'w')

current_working_dir = os.getcwd() # get the current working dir
num_class = 0 # the number of classes
no_label = 0 #no information in trainlabels.txt

for pic in pictures: # the list of pictures location
    #print pic
    name = os.path.basename(pic).split('.')[0] # basename: return the file name

    if name in train_dict: # dtr and dte is a dictionary
        label = train_dict[name]
    else:
        no_label += 1
        print('no label')
        continue

    pic = current_working_dir + '/' + pic + ';'
    for lb in label:
        pic = pic + str(lb) + ' '
        if (int(lb) + 1) > num_class:
            num_class = int(lb) + 1

    print(pic)
    f.write(pic+'\n')

f.write('classes;'+str(num_class))
f.close()

print('no class pictures: %d' % no_label)
print('number of classes: %d' % num_class)

pictures = glob.glob('data/test/*.png') # read all pictures
f = open('test_list.txt', 'w')
for pic in pictures: # the list of pictures location
    #print pic
    pic = current_working_dir + '/' + pic + ';'
    print(pic)
    f.write(pic+'\n')
"""


