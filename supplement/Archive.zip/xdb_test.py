import torch
import os
from PIL import Image
from torch.utils.data.dataset import Dataset
import numpy as np

class XDB_test(Dataset):
    def __init__(self, list_filename, transform=None):
        self.transform = transform
        # reading img file from file
        fp = open(list_filename, 'r')
        lines = fp.readlines()
        fp.close()

        pts = []
        nms = []
        labels = ['airplane', 'automobile', 'bird', 'cat', 'deer', \
                'dog', 'frog', 'horse', 'ship', 'truck']

        for x in lines:
            v = x.strip().split(';')[0]
            u = x.strip().split(';')[1]
            pts.append(v)
            nms.append(labels[int(u)])

        self.path  = pts
        self.name = nms

    def __getitem__(self, index):
        img = Image.open( self.path[index] )
        img = img.convert('RGB')
        if self.transform is not None:
            img = self.transform(img)

        lbs = self.name[index]
        return img, lbs

    def __len__(self):
        return len(self.path)
