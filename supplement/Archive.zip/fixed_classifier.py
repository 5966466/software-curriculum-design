import torch
import torch.nn as nn
from torch import tensor
import torch.nn.functional as F
from scipy.linalg import hadamard
import math

class fixed_classifier(nn.Module):
    def __init__(self, in_feat, num_classes, alpha, bias, mul):
        super().__init__()
        if mul:
            self.weight = nn.Parameter(tensor(0.5), requires_grad = True)
        else:
            pass

        dim = 2 ** int(math.ceil(math.log(max(in_feat, num_classes), 2)))
        #Since the dimension of hadamard matrix should be 2^x
        #To find the closest value to 2^x

        self.in_feat = in_feat
        self.num_classes = num_classes
        #truncated hadamard matrix where all C rows are orthogonal
        self.hada = hadamard(dim) / math.sqrt(dim)
        self.hada = torch.from_numpy(self.hada)
        #truncated hadamard matrix: C*N
        #self.trun_hada1 = hada[0:num_classes, 0:in_feat]
        #self.trun_hada2 = hada[0:num_classes, 0:in_feat]
        #self.trun_hada2[0, :] = -self.trun_hada2[0, :]
        #alpha is coefficient
        if alpha is not None:
            self.alpha = nn.Parameter(tensor(10.0), requires_grad = True)
        else:
            self.alpha = tensor(1.0)
        
        if bias:
            self.bias = nn.Parameter(torch.zeros((1, num_classes)), requires_grad = True)
        else:
            self.bias = torch.zeros((1, num_classes))

        self.eps = 1e-8

    def forward(self, x):
        self.hada = self.hada.type_as(x)
        if hasattr(self, 'weight'):
            trun_hada1 = self.hada[0:self.num_classes, 0:self.in_feat]
            trun_hada2 = self.hada[0:self.num_classes, 0:self.in_feat]
            trun_hada2[0, :] = -trun_hada2[0, :]
            w = self.weight * trun_hada1 + (1 - self.weight) * trun_hada2
        else:
            w = self.hada[1:self.num_classes+1, 0:self.in_feat]

        w = self.alpha * w
        b = self.bias.type_as(x)

        x_l2 = x.norm(p = 2, dim = 1, keepdim = True)
        x = x / (x_l2 + self.eps)
        return F.linear(x, w, b)